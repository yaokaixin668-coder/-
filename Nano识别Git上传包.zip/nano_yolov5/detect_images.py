"""用本目录 best.pt 识别图片，输出标框图片和 JSON。"""
import json
import inspect
import argparse
import pathlib
import sys
import time
from collections import Counter
from pathlib import Path

BASE = Path(__file__).resolve().parent
MODEL_PATH = BASE / "best.pt"
CONFIDENCE = 0.25
IMAGE_SIZE = 640


class Detector:
    def __init__(self, model_path=MODEL_PATH, device="auto"):
        import torch

        if device == "auto":
            device = "cuda:0" if torch.cuda.is_available() else "cpu"
        self.device = torch.device(device)
        sys.path.insert(0, str(BASE / "yolov5"))
        from models.common import AutoShape

        # 原版 YOLOv5 权重包含 Python 模型对象，仅加载自己信任的模型。
        original_path_class = pathlib.PosixPath
        try:
            if sys.platform == "win32":
                pathlib.PosixPath = pathlib.WindowsPath
            options = {"map_location": "cpu"}
            if "weights_only" in inspect.signature(torch.load).parameters:
                options["weights_only"] = False
            checkpoint = torch.load(str(model_path), **options)
        finally:
            pathlib.PosixPath = original_path_class
        model = checkpoint.get("ema")
        if model is None:
            model = checkpoint["model"]
        self.model = AutoShape(model.float().to(self.device).eval())
        self.model.conf = CONFIDENCE
        self.model.iou = 0.45
        self.names = self.model.names
        torch.set_num_threads(4)

    def identify(self, camera_image, save_dir=None):
        """路径或 OpenCV BGR 帧 -> 检测字典，可供后续 Auto 调用。"""
        from PIL import Image
        import numpy as np

        if isinstance(camera_image, (str, Path)):
            image_path = Path(camera_image)
            with Image.open(image_path) as source:
                image = source.convert("RGB")
            filename = image_path.name
        else:
            frame = np.asarray(camera_image)
            if frame.ndim != 3 or frame.shape[2] != 3:
                raise ValueError("摄像头帧需要为 H×W×3 的 BGR 数组")
            image = Image.fromarray(frame[:, :, ::-1].copy())
            filename = "camera_frame.jpg"
        started = time.perf_counter()
        results = self.model(image, size=IMAGE_SIZE)
        elapsed_ms = (time.perf_counter() - started) * 1000
        detections = []
        for x1, y1, x2, y2, confidence, class_id in results.xyxy[0].cpu().tolist():
            class_id = int(class_id)
            detections.append({
                "class_id": class_id,
                "class_name": self.names[class_id],
                "confidence": round(confidence, 4),
                "bbox": dict(zip(("x1", "y1", "x2", "y2"), [round(v, 2) for v in (x1, y1, x2, y2)])),
                "center": [round((x1 + x2) / 2, 2), round((y1 + y2) / 2, 2)],
                "area": round((x2 - x1) * (y2 - y1), 2),
            })
        counts = Counter(item["class_name"] for item in detections)
        names = self.names.values() if isinstance(self.names, dict) else self.names
        output = {
            "image": filename, "width": image.width, "height": image.height,
            "detections": detections,
            "count": {name: counts[name] for name in names},
            "inference_ms": round(elapsed_ms, 2),
        }
        if save_dir is not None:
            folder = Path(save_dir)
            folder.mkdir(parents=True, exist_ok=True)
            stem = Path(filename).stem
            (folder / (stem + ".json")).write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
            results.ims = [frame.copy() for frame in results.ims]
            Image.fromarray(results.render()[0]).save(folder / (stem + "_检测.jpg"))
        return output


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--device", default="auto", help="auto / cpu / cuda:0")
    arguments = parser.parse_args()
    detector = Detector(device=arguments.device)
    print("运行设备", detector.device, flush=True)
    print("模型类别", detector.names, flush=True)
    images = sorted((BASE / "images").glob("*.jpg"))
    for image in images:
        result = detector.identify(image, BASE / "results")
        print(json.dumps(result, ensure_ascii=False), flush=True)
    print("检测图片和 JSON 已保存到", BASE / "results", flush=True)


if __name__ == "__main__":
    main()
