"""Collect target environment without installing packages or opening hardware."""
import importlib
import platform
import sys
from pathlib import Path

print('Python', sys.version)
print('Architecture', platform.machine())
release = Path('/etc/nv_tegra_release')
print('L4T', release.read_text().strip() if release.exists() else 'not found')
for name in ('torch', 'torchvision', 'cv2', 'numpy', 'PIL', 'pandas', 'yaml', 'requests', 'scipy', 'tqdm', 'matplotlib', 'seaborn', 'psutil', 'thop', 'IPython', 'pkg_resources'):
    try:
        module = importlib.import_module(name)
        print(name, getattr(module, '__version__', 'OK'))
        if name == 'torch':
            print('CUDA build', module.version.cuda)
            print('CUDA available', module.cuda.is_available())
            if module.cuda.is_available():
                print('GPU', module.cuda.get_device_name(0))
    except Exception as error:
        print(name, 'ERROR', str(error))
