# Nano 上运行 YOLOv5 图片识别

将本目录的内容上传到 Git 仓库根目录。需要同时保留 best.pt、detect_images.py、check_env.py、images 和 yolov5。仓库中直接放文件和目录，便于拉取后运行。

## 先检查 Nano 环境

```bash
python3 check_env.py
```

请保留这条命令的完整输出。PyTorch 与 torchvision 必须匹配板子的 JetPack、Python 和 ARM64 架构，CUDA 支持也需要验证。当前未取得实际 Nano 的环境信息。

Windows 包原先的 requirements.txt 要求 torch>=2.6。这里根据 Jetson 环境单独安装依赖，先确定匹配版本。安装普通依赖时还需防止依赖解析升级板上已有的 torch、torchvision 或 numpy。项目保留了 YOLOv5 v7.0 源码，具体可运行的 Python 与库组合要在目标板核对。

NVIDIA 安装依据 https://docs.nvidia.com/deeplearning/frameworks/install-pytorch-jetson-platform/

## 在 Nano 下载仓库

将下面的占位地址替换成你的 Git 仓库 HTTPS 地址。

```bash
git clone 你的仓库HTTPS地址 nano_yolov5
cd nano_yolov5
python3 check_env.py
```

私有仓库需要使用有读取权限的账号凭据或 SSH 密钥。

## 环境就绪后运行

```bash
python3 detect_images.py
```

程序优先选择 CUDA，CUDA 不可用时选择 CPU。控制台显示运行设备、模型类别与 JSON。results 目录保存标框图片与 JSON，可通过文件管理器或 SSH 复制回电脑查看。

手动指定设备也可以运行。

```bash
python3 detect_images.py --device cpu
python3 detect_images.py --device cuda:0
```

后续更新仓库执行 git pull，再重新运行脚本。若在 Nano 上修改了受 Git 跟踪的文件，先保存或提交本地修改。

## 模型和结果

best.pt 为用户提供的 YOLOv5 权重，类别为 weed 和 corn。模型包含 Python 对象，只加载你信任的权重。

默认置信度阈值0.25，推理输入尺寸640。三张样例在 Windows CPU 上试跑通过，第一张中央大苗出现漏检。Nano 的运行、显存占用和帧率尚待实测。

本次功能为本地图片识别。摄像头实时推理需要先确认相机视频流地址，再接入 Detector.identify。识别结果对接之前的 Auto 时，需要将 corn 作为作物类别处理。

支持传入 OpenCV BGR 帧。示例调用如下。

```python
from detect_images import Detector

detector = Detector()
result = detector.identify(camera_image)
```

yolov5 目录来自 Ultralytics YOLOv5 v7.0，许可见 yolov5/LICENSE。
